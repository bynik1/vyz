# mkdir build

cd build
cmake ../

make string

# clear

./src/string/string
