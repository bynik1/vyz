#include <gtest/gtest.h>
#include "fts.h"  // Подключаем заголовочный файл библиотекии

// Тестирование функции add_floats
TEST(FTSTest, AddFloatsTest) {
  // Вызываем функцию add_floats с двумя числами
  double result = fts::add_floats(3.5, 2.0);

  // Проверяем, что результат равен ожидаемому значению
  EXPECT_FLOAT_EQ(result, 5.5);
}

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
